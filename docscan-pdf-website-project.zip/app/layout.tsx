import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DocScan PDF – Document Scanner & PDF Maker",
  description: "Scan documents, correct perspective, organize pages, and create clean PDFs with DocScan PDF for Android.",
  metadataBase: new URL("https://example.com")
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}