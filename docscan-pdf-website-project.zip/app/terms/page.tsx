import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Terms() {
  return <><Header /><main className="py-16"><div className="container max-w-3xl">
    <div className="text-sm font-bold uppercase tracking-wider text-blue-600">Legal</div>
    <h1 className="mt-3 text-4xl font-black">Terms & Conditions</h1>
    <div className="mt-10 grid gap-7 text-slate-600">
      <section><h2 className="font-bold text-slate-950">Acceptance</h2><p className="mt-2 leading-7">By using DocScan PDF, you agree to the terms that apply to the released product and its services.</p></section>
      <section><h2 className="font-bold text-slate-950">User responsibility</h2><p className="mt-2 leading-7">Users are responsible for documents they scan, store, share, and process, and for complying with applicable law.</p></section>
      <section><h2 className="font-bold text-slate-950">Availability</h2><p className="mt-2 leading-7">We do not guarantee uninterrupted availability or that every device will support every feature.</p></section>
      <section><h2 className="font-bold text-slate-950">Disclaimer</h2><p className="mt-2 leading-7">The product is provided subject to the limitations described in the final terms. No security or availability guarantee is absolute.</p></section>
      <section><h2 className="font-bold text-slate-950">Contact</h2><p className="mt-2 leading-7">Email: SUPPORT_EMAIL</p></section>
    </div>
  </div></main><Footer /></>;
}