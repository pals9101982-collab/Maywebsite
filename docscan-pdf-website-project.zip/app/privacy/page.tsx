import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Privacy() {
  return <><Header /><main className="py-16"><div className="container max-w-3xl">
    <div className="text-sm font-bold uppercase tracking-wider text-blue-600">Legal</div>
    <h1 className="mt-3 text-4xl font-black">Privacy Policy</h1>
    <p className="mt-3 text-sm text-slate-500">Effective date: 2026-08-30</p>
    <div className="prose prose-slate mt-10 max-w-none">
      <h2>Overview</h2><p>This template is provided for the DocScan PDF website and must be reviewed and updated to match the actual Android app before publication.</p>
      <h2>Information we collect</h2><p>State exactly what the website and Android app collect, including camera, selected media, diagnostics, analytics, or account information if any.</p>
      <h2>Scanned documents</h2><p>State whether documents are processed locally, uploaded, backed up, or shared with any service. Do not publish a claim that is not true of the released app.</p>
      <h2>Third parties</h2><p>List actual hosting, analytics, crash reporting, advertising, payment, or other third-party services used by the product.</p>
      <h2>Data retention and deletion</h2><p>Explain how long information is retained and how users can delete it.</p>
      <h2>Security</h2><p>Describe the security controls actually implemented. No software can guarantee absolute security.</p>
      <h2>Contact</h2><p>Email: SUPPORT_EMAIL</p>
    </div>
  </div></main><Footer /></>;
}