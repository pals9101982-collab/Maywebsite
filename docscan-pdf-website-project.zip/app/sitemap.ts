import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://example.com";
  return ["", "/security", "/faq", "/support", "/privacy", "/terms"].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date()
  }));
}