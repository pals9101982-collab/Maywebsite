import Header from "@/components/Header";
import Footer from "@/components/Footer";

const faqs = [
  ["Is DocScan PDF free?", "Set this answer to match the actual pricing model before publishing."],
  ["Does it work offline?", "If the released Android app performs its scanning and PDF workflow locally, the core workflow can work without an account or server."],
  ["Are scanned documents uploaded?", "The website does not receive scanned documents. The final answer for the Android app must match its actual implementation."],
  ["Can I create multi-page PDFs?", "Yes, the planned app workflow supports adding, reordering, editing, and deleting pages before PDF creation."],
  ["Can I create A4 PDFs?", "Yes. The planned PDF workflow supports A4 as well as A5, Letter, and Original Size."],
  ["Can I import images?", "Yes, the planned Android app supports importing one or multiple images."],
  ["Can I share PDFs?", "Yes, through Android's controlled file-sharing flow in the released app."],
  ["Do I need an account?", "The planned core app does not require account creation."]
];

export default function FAQ() {
  return <><Header /><main className="py-16"><div className="container max-w-3xl">
    <div className="text-sm font-bold uppercase tracking-wider text-blue-600">FAQ</div>
    <h1 className="mt-3 text-4xl font-black">Frequently asked questions</h1>
    <div className="mt-10 grid gap-4">{faqs.map(([q,a]) => <details key={q} className="rounded-2xl border border-slate-200 bg-white p-5"><summary className="cursor-pointer font-bold">{q}</summary><p className="mt-3 text-sm leading-6 text-slate-600">{a}</p></details>)}</div>
  </div></main><Footer /></>;
}