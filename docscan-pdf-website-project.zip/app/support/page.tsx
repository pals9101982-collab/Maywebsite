import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Support() {
  return <><Header /><main className="py-16"><div className="container max-w-2xl">
    <div className="text-sm font-bold uppercase tracking-wider text-blue-600">Support</div>
    <h1 className="mt-3 text-4xl font-black">How can we help?</h1>
    <p className="mt-4 text-slate-600">Replace the placeholder support email before publishing.</p>
    <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-6">
      <form action="mailto:SUPPORT_EMAIL" method="post" encType="text/plain" className="grid gap-4">
        <label className="grid gap-2 text-sm font-semibold">Name<input name="name" className="rounded-xl border border-slate-300 px-4 py-3 font-normal outline-none focus:border-blue-500" /></label>
        <label className="grid gap-2 text-sm font-semibold">Email<input name="email" type="email" required className="rounded-xl border border-slate-300 px-4 py-3 font-normal outline-none focus:border-blue-500" /></label>
        <label className="grid gap-2 text-sm font-semibold">Subject<input name="subject" required className="rounded-xl border border-slate-300 px-4 py-3 font-normal outline-none focus:border-blue-500" /></label>
        <label className="grid gap-2 text-sm font-semibold">Message<textarea name="message" rows={6} required className="rounded-xl border border-slate-300 px-4 py-3 font-normal outline-none focus:border-blue-500" /></label>
        <button className="rounded-xl bg-slate-950 px-5 py-3 font-semibold text-white">Contact Support</button>
      </form>
    </div>
  </div></main><Footer /></>;
}