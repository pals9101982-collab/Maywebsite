import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PhoneMockup from "@/components/PhoneMockup";
import { ArrowRight, Check, Crop, FileText, ImagePlus, LockKeyhole, ScanLine, Settings2, WandSparkles } from "lucide-react";

const features = [
  ["Document Scanner", "Capture paper documents with your Android camera.", ScanLine],
  ["Auto Edge Detection", "Detect document boundaries and help create accurate crops.", Crop],
  ["Perspective Correction", "Straighten tilted or angled documents for cleaner results.", WandSparkles],
  ["Document Filters", "Use Auto, Black & White, Grayscale, Document, or High Contrast.", Settings2],
  ["Multi-Page PDF", "Combine multiple scanned pages into one organized PDF.", FileText],
  ["Gallery Import", "Import one or multiple existing images for conversion.", ImagePlus],
  ["Secure File Handling", "Use controlled local file handling and sharing.", LockKeyhole],
  ["PDF Page Sizes", "Create documents using A4, A5, Letter, or Original Size.", Check]
];

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <section className="grid-bg overflow-hidden">
          <div className="container grid items-center gap-12 py-20 md:grid-cols-2 md:py-28">
            <div>
              <div className="inline-flex rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                Document Scanner & PDF Maker for Android
              </div>
              <h1 className="mt-6 text-5xl font-black tracking-tight text-slate-950 md:text-6xl">
                Scan documents.<br />
                Create PDFs.<br />
                <span className="text-blue-600">Keep them private.</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-8 text-slate-600">
                Turn paper documents into clean, organized PDFs directly from your Android phone.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#" className="rounded-xl bg-slate-950 px-5 py-3 font-semibold text-white hover:bg-slate-800">
                  Download on Google Play
                </a>
                <Link href="#features" className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-3 font-semibold text-slate-800">
                  Explore features <ArrowRight size={17} />
                </Link>
              </div>
              <div className="mt-6 flex flex-wrap gap-5 text-sm text-slate-500">
                <span className="flex items-center gap-2"><Check size={16} /> Multi-page PDFs</span>
                <span className="flex items-center gap-2"><Check size={16} /> A4 support</span>
                <span className="flex items-center gap-2"><Check size={16} /> Android-first</span>
              </div>
            </div>
            <div className="relative">
              <PhoneMockup />
            </div>
          </div>
        </section>

        <section id="features" className="bg-white py-20">
          <div className="container">
            <div className="max-w-2xl">
              <div className="text-sm font-bold uppercase tracking-wider text-blue-600">Features</div>
              <h2 className="mt-3 text-4xl font-black tracking-tight">Everything you need to turn paper into PDF.</h2>
              <p className="mt-4 leading-7 text-slate-600">A focused scanner workflow without unnecessary complexity.</p>
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {features.map(([title, desc, Icon]) => {
                const I = Icon as typeof ScanLine;
                return <div key={title as string} className="rounded-2xl border border-slate-200 p-5">
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-blue-50 text-blue-600"><I size={21} /></div>
                  <h3 className="mt-5 font-bold">{title as string}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-500">{desc as string}</p>
                </div>;
              })}
            </div>
          </div>
        </section>

        <section id="how-it-works" className="py-20">
          <div className="container">
            <div className="text-center">
              <div className="text-sm font-bold uppercase tracking-wider text-blue-600">How it works</div>
              <h2 className="mt-3 text-4xl font-black">Four simple steps.</h2>
            </div>
            <div className="mt-12 grid gap-5 md:grid-cols-4">
              {[
                ["01", "Scan", "Point the camera at a document and capture it."],
                ["02", "Adjust", "Crop, correct perspective, rotate, and enhance."],
                ["03", "Organize", "Add pages, reorder them, or remove unwanted pages."],
                ["04", "Create PDF", "Choose your page size and generate your PDF."]
              ].map(([n, t, d]) => <div key={n} className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
                <div className="text-sm font-black text-blue-600">{n}</div>
                <h3 className="mt-5 text-xl font-bold">{t}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-500">{d}</p>
              </div>)}
            </div>
          </div>
        </section>

        <section className="bg-slate-950 py-20 text-white">
          <div className="container grid items-center gap-10 md:grid-cols-2">
            <div>
              <div className="text-sm font-bold uppercase tracking-wider text-blue-300">Privacy first</div>
              <h2 className="mt-3 text-4xl font-black">Your documents deserve careful handling.</h2>
              <p className="mt-5 max-w-xl leading-7 text-slate-300">
                DocScan PDF is designed around local document workflows, minimal permissions, and controlled file sharing. The exact privacy behavior depends on the Android app implementation.
              </p>
              <Link href="/security" className="mt-7 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 font-semibold text-slate-950">
                Read security & privacy <ArrowRight size={17} />
              </Link>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-7">
              {["Local-first document workflow", "Minimal permissions", "Controlled PDF sharing", "No fake security promises"].map(x =>
                <div key={x} className="flex items-center gap-3 border-b border-white/10 py-4 last:border-0">
                  <Check size={18} className="text-blue-300" /> <span>{x}</span>
                </div>
              )}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container rounded-3xl bg-blue-600 px-7 py-14 text-center text-white md:px-16">
            <h2 className="text-4xl font-black">Ready to turn paper into PDFs?</h2>
            <p className="mx-auto mt-4 max-w-xl text-blue-100">Scan, organize, and create clean PDFs from your Android phone.</p>
            <a href="#" className="mt-8 inline-block rounded-xl bg-white px-6 py-3 font-bold text-blue-700">Download DocScan PDF</a>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}