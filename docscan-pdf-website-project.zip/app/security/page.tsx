import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Security() {
  return <><Header /><main className="py-16"><div className="container max-w-3xl">
    <div className="text-sm font-bold uppercase tracking-wider text-blue-600">Security & Privacy</div>
    <h1 className="mt-3 text-4xl font-black">Security is a process, not a promise of being unhackable.</h1>
    <p className="mt-5 leading-7 text-slate-600">No software can honestly be described as completely immune to attacks. DocScan PDF is intended to use defense-in-depth Android security practices to reduce risk.</p>
    <div className="mt-10 grid gap-4">
      {[
        ["Local-first workflow", "Where implemented, document processing and storage stay on the device rather than being uploaded to a server."],
        ["Secure file handling", "The Android app should use private app storage and controlled sharing mechanisms for sensitive documents."],
        ["Minimal permissions", "The app should request only permissions required for scanning and user-selected imports."],
        ["Authentication", "Optional biometric/device-credential protection can be used for protected documents when implemented."],
        ["No unnecessary uploads", "The website does not need access to your scanned documents."],
        ["Transparent claims", "Security and privacy statements should always match the behavior of the released Android app."]
      ].map(([t,d]) => <section key={t} className="rounded-2xl border border-slate-200 bg-white p-6"><h2 className="font-bold">{t}</h2><p className="mt-2 text-sm leading-6 text-slate-600">{d}</p></section>)}
    </div>
  </div></main><Footer /></>;
}