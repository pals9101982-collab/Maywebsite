# DocScan PDF Website

Official companion website starter for the DocScan PDF Android app.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Before publishing

Replace these placeholders:
- `https://example.com`
- `GOOGLE_PLAY_URL` / `href="#"` Play buttons
- `SUPPORT_EMAIL`
- `COMPANY_NAME` where needed

Most importantly, review the Privacy Policy and Security page so every statement matches the actual Android app implementation.

## Build

```bash
npm run build
npm start
```
