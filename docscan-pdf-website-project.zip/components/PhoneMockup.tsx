import { Camera, FileText, ScanLine, Sparkles } from "lucide-react";

export default function PhoneMockup() {
  return (
    <div className="phone mx-auto">
      <div className="phone-notch" />
      <div className="flex h-full flex-col bg-slate-50">
        <div className="px-5 pb-4 pt-9">
          <div className="text-xs font-medium text-slate-500">Welcome back</div>
          <div className="mt-1 text-xl font-bold">DocScan PDF</div>
        </div>
        <div className="mx-4 rounded-3xl bg-blue-600 p-5 text-white">
          <div className="flex items-center justify-between">
            <ScanLine size={28} />
            <span className="rounded-full bg-white/15 px-2 py-1 text-[10px]">A4 PDF</span>
          </div>
          <div className="mt-8 text-lg font-bold">Scan a document</div>
          <div className="mt-1 text-xs text-blue-100">Auto crop & perspective correction</div>
          <button className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-white py-3 text-sm font-bold text-blue-700">
            <Camera size={17} /> Start scanning
          </button>
        </div>
        <div className="px-5 pt-6">
          <div className="flex items-center justify-between">
            <span className="font-bold">Recent PDFs</span>
            <FileText size={18} className="text-slate-400" />
          </div>
          <div className="mt-4 grid gap-3">
            {["Project notes.pdf", "Invoice March.pdf", "ID documents.pdf"].map((x, i) => (
              <div key={x} className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-sm">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-blue-50 text-blue-600">
                  {i === 0 ? <Sparkles size={17} /> : <FileText size={17} />}
                </div>
                <div className="min-w-0">
                  <div className="truncate text-xs font-semibold">{x}</div>
                  <div className="text-[10px] text-slate-400">PDF • {i + 2} pages</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}