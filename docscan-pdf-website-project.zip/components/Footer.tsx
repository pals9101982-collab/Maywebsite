import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="container grid gap-10 py-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="text-lg font-bold">DocScan PDF</div>
          <p className="mt-3 max-w-md text-sm leading-6 text-slate-500">
            Scan documents, organize pages, and create clean PDFs from your Android phone.
          </p>
        </div>
        <div>
          <div className="font-semibold">Product</div>
          <div className="mt-3 grid gap-2 text-sm text-slate-500">
            <Link href="/#features">Features</Link>
            <Link href="/#how-it-works">How it works</Link>
            <Link href="/security">Security & Privacy</Link>
            <Link href="/faq">FAQ</Link>
          </div>
        </div>
        <div>
          <div className="font-semibold">Legal & Help</div>
          <div className="mt-3 grid gap-2 text-sm text-slate-500">
            <Link href="/support">Support</Link>
            <Link href="/privacy">Privacy Policy</Link>
            <Link href="/terms">Terms & Conditions</Link>
          </div>
        </div>
      </div>
      <div className="border-t border-slate-200 py-5 text-center text-xs text-slate-500">
        © 2026 DocScan PDF. All rights reserved.
      </div>
    </footer>
  );
}