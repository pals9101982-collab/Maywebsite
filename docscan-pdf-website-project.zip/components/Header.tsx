import Link from "next/link";
import { FileScan } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold text-slate-950">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-blue-600 text-white">
            <FileScan size={20} />
          </span>
          DocScan PDF
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-slate-600 md:flex">
          <Link href="/#features" className="hover:text-blue-600">Features</Link>
          <Link href="/#how-it-works" className="hover:text-blue-600">How it works</Link>
          <Link href="/security" className="hover:text-blue-600">Security</Link>
          <Link href="/faq" className="hover:text-blue-600">FAQ</Link>
          <Link href="/support" className="hover:text-blue-600">Support</Link>
        </nav>
        <a href="#" className="rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800">
          Google Play
        </a>
      </div>
    </header>
  );
}